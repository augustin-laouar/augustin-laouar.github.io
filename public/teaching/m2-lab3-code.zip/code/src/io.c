#include "io.h"

int file_load(Buffer *B, const char *path) 
{
    // TODO
}
int file_save(const Buffer *B, const char *path) 
{
    // TODO
}