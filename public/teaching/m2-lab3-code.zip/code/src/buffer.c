#include "buffer.h"

void line_init(Line *L) 
{
    // TODO
}
void line_free(Line *L) 
{
    // TODO
}
void line_reserve(Line *L, size_t need) 
{
    // TODO
}
void line_insert_char(Line *L, size_t col, char ch) 
{
    // TODO
}
void line_delete_char(Line *L, size_t col) 
{
    // TODO
}
void buffer_init(Buffer *B) 
{
    // TODO
}
void buffer_free(Buffer *B) 
{
    // TODO
}
void buffer_reserve(Buffer *B, size_t need) 
{
    // TODO
}
void buffer_insert_line(Buffer *B, size_t idx, const char *s) 
{
    // TODO
}
void buffer_delete_line(Buffer *B, size_t idx) 
{
    // TODO
}
void buffer_split_line(Buffer *B, size_t row, size_t col) 
{
    // TODO
}
void buffer_join_with_previous(Buffer *B, size_t row) 
{
    // TODO
}