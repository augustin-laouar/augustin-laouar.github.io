#include "input.h"

void move_left(Editor *E) 
{
    // TODO
}
void move_right(Editor *E) 
{
    // TODO
}
void move_up(Editor *E) 
{
    // TODO
}
void move_down(Editor *E) 
{
    // TODO
}
void insert_char_at_cursor(Editor *E, char ch) 
{
    // TODO
}
void insert_newline_at_cursor(Editor *E) 
{
    // TODO
}
void backspace_at_cursor(Editor *E) 
{
    // TODO
}
void handle_key(Editor *E, int key) 
{
    // TODO
}
